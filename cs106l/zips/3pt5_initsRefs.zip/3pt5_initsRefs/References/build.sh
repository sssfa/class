g++ -Wall -Werror -std=c++17 references_mess.cpp -o references_mess
g++ -Wall -Werror -std=c++17 r_spaghetti.cpp -o r_spaghetti