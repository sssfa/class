#!/bin/bash

# build
g++ -Wall -Werror -std=c++17 iterators_and_pointers.cpp -o iandp
